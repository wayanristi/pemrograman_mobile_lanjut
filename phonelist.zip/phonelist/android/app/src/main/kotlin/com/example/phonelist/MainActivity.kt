package com.example.phonelist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
